<div id="loading-animation" class="fixed top-0 right-0 h-screen w-screen z-50 flex justify-center items-center bg-white">
    <div class="animate-spin rounded-full h-32 w-32 border-t-4 border-b-4 border-gray-900"></div>
</div>