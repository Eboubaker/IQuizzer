<footer class="flex align-items-center justify-center w-full bg-gray-800 h-24 text-center">
    <div class="my-auto text-white">
        Quizzer&copy; All rights reserved 2020

    </div>
</footer>